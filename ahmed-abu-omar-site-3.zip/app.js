/* Ahmed Abu Omar Studio: progressive enhancement only. Every page is complete HTML without this file. */
(function () {
'use strict';
var $ = function (id) { return document.getElementById(id); };
var LANG = document.documentElement.lang === 'en' ? 'en' : 'ar';
var REDUCE = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var FINE = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
var L = {
  ar: { copied: 'تم النسخ', copyFail: 'تعذر النسخ، حدد النص يدوياً', before: 'قبل', after: 'بعد', dl: 'تحميل', cantRead: 'تعذر قراءة الملف', wgEmpty: 'اكتب الرقم لتظهر الروابط هنا',
        home: 'الرئيسية', about: 'عنا', cvIntro: 'السلام عليكم، أرغب في طلب خدمة تصميم CV مخصص بسعر 150 جنيه ($3).',
        cvName: 'الاسم', cvJob: 'المسمى الوظيفي', cvExp: 'سنوات الخبرة', cvLang: 'لغة السيرة', cvNotes: 'ملاحظات' },
  en: { copied: 'Copied', copyFail: 'Copy failed, select the text manually', before: 'Before', after: 'After', dl: 'Download', cantRead: 'Could not read file', wgEmpty: 'Enter a number to see the link here',
        home: 'Home', about: 'About', cvIntro: 'Hello, I would like to order the custom CV design service (150 EGP / $3).',
        cvName: 'Name', cvJob: 'Job title', cvExp: 'Years of experience', cvLang: 'CV language', cvNotes: 'Notes' }
}[LANG];

function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
var toastT;
function toast(m) { var t = $('toast'); if (!t) return; t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 2000); }
function copy(text) {
  function fb() { var ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) {} document.body.removeChild(ta); toast(ok ? L.copied : L.copyFail); }
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { toast(L.copied); }, fb); else fb();
}
function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

/* ---------- WebGL cinematic background (deferred, optional) ---------- */
function initBg() {
  var cv = $('bg'); if (!cv) return;
  var gl = null; try { gl = cv.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'low-power' }) || cv.getContext('experimental-webgl'); } catch (e) {}
  if (!gl) return;
  var vs = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var fs = [
    '#ifdef GL_FRAGMENT_PRECISION_HIGH', 'precision highp float;', '#else', 'precision mediump float;', '#endif',
    'uniform vec2 uRes;uniform float uT;uniform vec2 uM;uniform float uS;',
    'float h(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}',
    'float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}',
    'float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*n(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return v;}',
    'void main(){',
    ' vec2 uv=gl_FragCoord.xy/uRes;float asp=uRes.x/uRes.y;vec2 p=(uv-.5)*vec2(asp,1.);',
    ' float t=uT*.035;vec2 sc=vec2(0.,uS*.12);',
    ' vec2 q=vec2(fbm(p*1.3+sc+vec2(0.,t)),fbm(p*1.3+sc+vec2(5.2,1.3)-t));',
    ' vec2 r=vec2(fbm(p*1.6+3.*q+vec2(1.7,9.2)+t*1.2),fbm(p*1.6+3.*q+vec2(8.3,2.8)-t));',
    ' float f=fbm(p*1.1+3.*r);',
    ' vec3 deep=vec3(.02,.04,.09),teal=vec3(.06,.46,.50),amber=vec3(.95,.50,.16);',
    ' vec3 col=vec3(.012,.016,.028);',
    ' col+=mix(deep,teal,smoothstep(.25,.85,f))*smoothstep(.2,.9,f)*1.1;',
    ' col+=amber*pow(smoothstep(.5,1.,r.x*f*1.7),2.2)*.34;',
    ' vec2 m=(uM-.5)*vec2(asp,1.);float d=length(p-m);',
    ' col+=amber*.12/(d*4.+.35);',
    ' col+=vec3(.25,.70,.75)*exp(-abs(p.y-m.y)*26.)*exp(-abs(p.x-m.x)*1.3)*.24;',
    ' float sy=.22+.04*sin(uT*.2);',
    ' col+=vec3(.9,.55,.3)*exp(-abs(p.y-sy)*40.)*exp(-abs(p.x+.2)*1.1)*.08;',
    ' col*=1.-.65*dot(uv-.5,uv-.5)*2.;',
    ' col+=(h(gl_FragCoord.xy+fract(uT)*91.)-.5)*.04;',
    ' gl_FragColor=vec4(max(col,0.),1.);}'
  ].join('\n');
  function sh(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null; }
  var v = sh(gl.VERTEX_SHADER, vs), f = sh(gl.FRAGMENT_SHADER, fs); if (!v || !f) return;
  var pr = gl.createProgram(); gl.attachShader(pr, v); gl.attachShader(pr, f); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return;
  gl.useProgram(pr);
  var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  var loc = gl.getAttribLocation(pr, 'a'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  var uRes = gl.getUniformLocation(pr, 'uRes'), uT = gl.getUniformLocation(pr, 'uT'), uM = gl.getUniformLocation(pr, 'uM'), uS = gl.getUniformLocation(pr, 'uS');
  var tx = .72, ty = .62, cx = .72, cy = .62, start = performance.now(), raf = 0, running = false;
  function draw(now) {
    cx += (tx - cx) * .06; cy += (ty - cy) * .06;
    gl.uniform1f(uT, REDUCE ? 3 : (now - start) / 1000); gl.uniform2f(uM, cx, cy);
    gl.uniform1f(uS, window.scrollY / Math.max(1, window.innerHeight)); gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  function resize() {
    var sc = window.innerWidth < 700 ? .8 : .5, w = Math.max(2, Math.floor(window.innerWidth * sc)), h = Math.max(2, Math.floor(window.innerHeight * sc));
    cv.width = w; cv.height = h; gl.viewport(0, 0, w, h); gl.uniform2f(uRes, w, h); if (REDUCE || !running) draw(0);
  }
  function loop(now) { if (!running) return; draw(now); raf = requestAnimationFrame(loop); }
  function play() { if (REDUCE || running) return; running = true; raf = requestAnimationFrame(loop); }
  function stop() { running = false; cancelAnimationFrame(raf); }
  window.addEventListener('resize', resize);
  window.addEventListener('pointermove', function (e) { tx = e.clientX / window.innerWidth; ty = 1 - e.clientY / window.innerHeight; }, { passive: true });
  document.addEventListener('visibilitychange', function () { document.hidden ? stop() : play(); });
  cv.addEventListener('webglcontextlost', function (e) { e.preventDefault(); stop(); });
  resize(); play();
}

/* ---------- interaction polish ---------- */
function initFx() {
  var tc = $('tc');
  if (tc && !REDUCE) setInterval(function () {
    if (document.hidden) return;
    var ms = Math.floor(performance.now()), p = function (n) { return (n < 10 ? '0' : '') + n; };
    tc.textContent = p(Math.floor(ms / 3600000)) + ':' + p(Math.floor(ms / 60000) % 60) + ':' + p(Math.floor(ms / 1000) % 60) + ':' + p(Math.floor(ms / 40) % 25);
  }, 80);
  var g = $('glow');
  if (g && FINE && !REDUCE) {
    var gx = 0, gy = 0, pend = 0;
    window.addEventListener('pointermove', function (e) { gx = e.clientX; gy = e.clientY; g.style.opacity = '1'; if (!pend) pend = requestAnimationFrame(function () { pend = 0; g.style.transform = 'translate(' + gx + 'px,' + gy + 'px)'; }); }, { passive: true });
  }
  if (FINE && !REDUCE) {
    document.addEventListener('pointermove', function (e) {
      var c = e.target.closest && e.target.closest('.card'); if (!c) return;
      var r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      c.style.setProperty('--mx', (x * 100).toFixed(1) + '%'); c.style.setProperty('--my', (y * 100).toFixed(1) + '%');
      c.style.setProperty('--ry', ((x - .5) * 8).toFixed(2) + 'deg'); c.style.setProperty('--rx', ((.5 - y) * 6).toFixed(2) + 'deg');
    }, { passive: true });
    document.addEventListener('pointerout', function (e) {
      var c = e.target.closest && e.target.closest('.card');
      if (c && !c.contains(e.relatedTarget)) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); }
    });
  }
  if ('IntersectionObserver' in window && !REDUCE) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { threshold: .06 });
    document.querySelectorAll('main > section, .sec-head, .steps li, .contact-cards .cc').forEach(function (n) {
      if (n.getBoundingClientRect().top > window.innerHeight * .9) { n.classList.add('pre'); io.observe(n); }
    });
  }
}

/* ---------- hero template playground (home pages) ---------- */
var MT = {
  ar: {
    tabs: [['rest', 'مطعم'], ['estate', 'عقارات'], ['law', 'محاماة'], ['port', 'معرض أعمال'], ['saas', 'SaaS']], fonts: [['sans', 'عصري'], ['serif', 'كلاسيكي']],
    rest: { n: 'مقهى النيل', h: 'قهوة وطعام بنكهة محلية', p: 'قائمة الطعام وحجز الطاولات في صفحة واحدة.', b: 'احجز طاولة', c: [['قهوة تركية', '45 ج.م'], ['مشاوي مشكلة', '180 ج.م'], ['كنافة', '70 ج.م']] },
    estate: { n: 'نوفا العقارية', h: 'ابحث عن بيتك القادم', p: 'تصفح الوحدات حسب المنطقة والسعر.', b: 'ابحث الآن', c: [['شقة 3 غرف', '2.4 مليون'], ['فيلا', '7.9 مليون'], ['استوديو', '1.1 مليون']] },
    law: { n: 'مكتب ميوم', h: 'استشارات قانونية موثوقة', p: 'تعرّف على مجالات الخبرة واحجز استشارتك.', b: 'احجز استشارة', c: [['الشركات', ''], ['العقود', ''], ['القضايا', '']] },
    port: { n: 'أحمد', h: 'مصمم ومطور مواقع', p: 'مشاريع مختارة وطريقة سريعة للتواصل.', b: 'شاهد الأعمال', c: [['مشروع 01', 'Web'], ['مشروع 02', 'Brand'], ['مشروع 03', 'App']] },
    saas: { n: 'Flowly', h: 'أدر عملك من مكان واحد', p: 'لوحة تحكم وتقارير وتسعير واضح.', b: 'ابدأ تجربة', c: [['التقارير', '24'], ['المهام', '118'], ['الفرق', '6']] }
  },
  en: {
    tabs: [['rest', 'Restaurant'], ['estate', 'Real estate'], ['law', 'Law firm'], ['port', 'Portfolio'], ['saas', 'SaaS']], fonts: [['sans', 'Modern'], ['serif', 'Classic']],
    rest: { n: 'Nile Cafe', h: 'Coffee and food with a local touch', p: 'Menu and table booking on a single page.', b: 'Book a table', c: [['Turkish coffee', '45 EGP'], ['Mixed grill', '180 EGP'], ['Kunafa', '70 EGP']] },
    estate: { n: 'Nova Estates', h: 'Find your next home', p: 'Browse units by area and price.', b: 'Search now', c: [['3-bed apartment', '2.4M EGP'], ['Villa', '7.9M EGP'], ['Studio', '1.1M EGP']] },
    law: { n: 'Mium Law', h: 'Trusted legal counsel', p: 'See practice areas and book a consultation.', b: 'Book a consultation', c: [['Corporate', ''], ['Contracts', ''], ['Litigation', '']] },
    port: { n: 'Ahmed', h: 'Designer and web developer', p: 'Selected projects and a quick way to get in touch.', b: 'View work', c: [['Project 01', 'Web'], ['Project 02', 'Brand'], ['Project 03', 'App']] },
    saas: { n: 'Flowly', h: 'Run your business from one place', p: 'A dashboard, reports and clear pricing.', b: 'Start a trial', c: [['Reports', '24'], ['Tasks', '118'], ['Teams', '6']] }
  }
}[LANG];
var pgType = 'rest', pgFont = 'sans', pgAuto = true, PG_COLS = ['#E8590C', '#0E9F6E', '#2F6BFF', '#8B3FE8', '#E11D48'];
function renderPlayground() {
  var d = MT[pgType], tabs = $('pgTabs'), f = $('fonts'); tabs.textContent = ''; f.textContent = '';
  MT.tabs.forEach(function (x) { var b = el('button', null, x[1]); b.type = 'button'; b.setAttribute('aria-pressed', String(pgType === x[0])); b.addEventListener('click', function () { pgAuto = false; pgType = x[0]; renderPlayground(); }); tabs.appendChild(b); });
  MT.fonts.forEach(function (x) { var b = el('button', null, x[1]); b.type = 'button'; b.setAttribute('aria-pressed', String(pgFont === x[0])); b.addEventListener('click', function () { pgAuto = false; pgFont = x[0]; renderPlayground(); }); f.appendChild(b); });
  $('mock').style.setProperty('--mf', pgFont === 'serif' ? 'Georgia,"Times New Roman",serif' : 'var(--font-display)');
  var nav = '<div class="pn"><b>' + esc(d.n) + '</b><span>' + L.home + '</span><span>' + L.about + '</span></div>';
  var cards = '<div class="pc3">' + d.c.map(function (c) { return '<div class="pcard"><i></i><b>' + esc(c[0]) + '</b>' + (c[1] ? '<em>' + esc(c[1]) + '</em>' : '') + '</div>'; }).join('') + '</div>';
  var txt = '<div><div class="ph">' + esc(d.h) + '</div><div class="pp">' + esc(d.p) + '</div><span class="pb">' + esc(d.b) + '</span></div>', html;
  if (pgType === 'rest') html = nav + '<div class="pgc"><div class="ph">' + esc(d.h) + '</div><div class="pp">' + esc(d.p) + '</div><span class="pb">' + esc(d.b) + '</span></div>' + cards;
  else if (pgType === 'saas') html = nav + '<div class="pg2">' + txt + '<div class="pbars"><i style="height:35%"></i><i style="height:55%"></i><i style="height:42%"></i><i style="height:78%"></i><i style="height:62%"></i><i style="height:92%"></i></div></div>' + cards;
  else html = nav + '<div class="pg2">' + txt + '<div class="pa"></div></div>' + cards;
  $('mockPage').innerHTML = html;
}
function setColor(i) { $('mock').style.setProperty('--m', PG_COLS[i]); $('swatches').querySelectorAll('button').forEach(function (x, k) { x.setAttribute('aria-pressed', String(k === i)); }); }
function initPlayground() {
  if (!$('mockPage')) return;
  var box = $('swatches');
  PG_COLS.forEach(function (c, i) { var b = el('button'); b.type = 'button'; b.style.background = c; b.setAttribute('aria-label', c); b.setAttribute('aria-pressed', String(i === 0)); b.addEventListener('click', function () { pgAuto = false; setColor(i); }); box.appendChild(b); });
  renderPlayground();
  if (!REDUCE) { var idx = 0; setInterval(function () { if (!pgAuto || document.hidden) return; idx = (idx + 1) % MT.tabs.length; pgType = MT.tabs[idx][0]; setColor(idx); renderPlayground(); }, 4200); }
}

/* ---------- product tabs (English home) ---------- */
function initTabs() {
  var tabs = $('tabs'); if (!tabs) return;
  var btns = tabs.querySelectorAll('button');
  btns.forEach(function (b) {
    b.addEventListener('click', function () {
      var c = b.getAttribute('data-cat');
      btns.forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      document.querySelectorAll('#grid .card').forEach(function (card) { card.hidden = !(c === 'all' || card.getAttribute('data-cat') === c); });
    });
  });
}

/* ---------- free tools ---------- */
function initTools() {
  if (!$('drop')) return;
  var lastFiles = [], urls = [];
  function compress(files) {
    var box = $('results'); urls.forEach(function (u) { URL.revokeObjectURL(u); }); urls = []; box.textContent = '';
    files = Array.prototype.filter.call(files || [], function (f) { return /^image\//.test(f.type); }); lastFiles = files;
    var qual = parseInt($('quality').value, 10) / 100, wi = parseInt($('maxW').value, 10), hi = parseInt($('maxH').value, 10);
    files.forEach(function (f) {
      var u = URL.createObjectURL(f); urls.push(u); var img = new Image();
      img.onerror = function () { box.appendChild(el('div', 'res', L.cantRead + ': ' + f.name)); };
      img.onload = function () {
        var mw = wi > 0 ? wi : Infinity, mh = hi > 0 ? hi : Infinity; if (!(wi > 0) && !(hi > 0)) { mw = 1600; mh = 1600; }
        var s = Math.min(mw / img.width, mh / img.height, 1), w = Math.max(1, Math.round(img.width * s)), h = Math.max(1, Math.round(img.height * s));
        var c = document.createElement('canvas'); c.width = w; c.height = h; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(img, 0, 0, w, h);
        c.toBlob(function (b) {
          if (!b) return; var ou = URL.createObjectURL(b); urls.push(ou);
          var r = el('div', 'res'); r.appendChild(el('b', null, f.name + ' (' + w + '×' + h + ')'));
          r.appendChild(el('span', null, L.before + ' ' + (f.size / 1024).toFixed(1) + ' KB → ' + L.after + ' ' + (b.size / 1024).toFixed(1) + ' KB'));
          var a = el('a', 'btn btn-sm', L.dl); a.href = ou; a.download = f.name.replace(/\.[^.]+$/, '') + '_' + w + 'x' + h + '.jpg'; r.appendChild(a); box.appendChild(r);
        }, 'image/jpeg', qual);
      };
      img.src = u;
    });
  }
  var dz = $('drop'), fi = $('file');
  dz.addEventListener('click', function () { fi.click(); });
  dz.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fi.click(); } });
  fi.addEventListener('change', function () { compress(fi.files); });
  ['dragenter', 'dragover'].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.add('over'); }); });
  ['dragleave', 'drop'].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.remove('over'); }); });
  dz.addEventListener('drop', function (e) { compress(e.dataTransfer.files); });
  $('quality').addEventListener('input', function () { $('qv').textContent = this.value; });
  ['quality', 'maxW', 'maxH'].forEach(function (id) { $(id).addEventListener('change', function () { if (lastFiles.length) compress(lastFiles); }); });

  function hsl2hex(h, s, l) { s /= 100; l /= 100; var k = function (n) { return (n + h / 30) % 12; }, a = s * Math.min(l, 1 - l), f = function (n) { var v = l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return Math.round(255 * v).toString(16).padStart(2, '0'); }; return ('#' + f(0) + f(8) + f(4)).toUpperCase(); }
  var gradCss = '';
  function genPalette() {
    var h = Math.floor(Math.random() * 360), sets = [[0, 62, 48], [28, 55, 58], [200, 50, 40], [180, 60, 66], [320, 55, 52]];
    var cols = sets.map(function (s, i) { return hsl2hex((h + s[0]) % 360, s[1], i === 2 ? 24 : s[2]); });
    var box = $('pal'); box.textContent = '';
    cols.forEach(function (c) { var b = el('button'); b.type = 'button'; b.setAttribute('aria-label', c); var sw = el('i'); sw.style.background = c; b.appendChild(sw); b.appendChild(el('code', null, c)); b.addEventListener('click', function () { copy(c); }); box.appendChild(b); });
    gradCss = 'linear-gradient(135deg, ' + cols[0] + ', ' + cols[1] + ', ' + cols[3] + ')';
    $('grad').style.background = gradCss; $('gradCode').textContent = 'background: ' + gradCss + ';';
  }
  $('genBtn').addEventListener('click', genPalette); $('copyGrad').addEventListener('click', function () { copy('background: ' + gradCss + ';'); }); genPalette();

  function updateWa() {
    var n = $('wgNum').value.replace(/\D/g, ''), m = $('wgMsg').value.trim(), out = $('wgOut'), open = $('wgOpen');
    if (!n) { out.textContent = L.wgEmpty; open.removeAttribute('href'); open.setAttribute('aria-disabled', 'true'); return; }
    var link = 'https://wa.me/' + n + (m ? '?text=' + encodeURIComponent(m) : '');
    out.textContent = link; open.href = link; open.removeAttribute('aria-disabled');
  }
  $('wgNum').addEventListener('input', updateWa); $('wgMsg').addEventListener('input', updateWa);
  $('wgCopy').addEventListener('click', function () { if ($('wgNum').value.replace(/\D/g, '')) copy($('wgOut').textContent); }); updateWa();
}

/* ---------- CV order builder (cv-design page) ---------- */
function initCv() {
  var form = $('cvForm'); if (!form) return;
  var WA = form.getAttribute('data-wa');
  function build() {
    var lines = [L.cvIntro], add = function (label, id) { var v = $(id).value.trim(); if (v) lines.push(label + ': ' + v); };
    add(L.cvName, 'cvName'); add(L.cvJob, 'cvJob'); add(L.cvExp, 'cvExp'); add(L.cvLang, 'cvLang'); add(L.cvNotes, 'cvNotes');
    var text = lines.join('\n'); $('cvPreview').textContent = text; $('cvSend').href = 'https://wa.me/' + WA + '?text=' + encodeURIComponent(text);
  }
  form.addEventListener('input', build); form.addEventListener('submit', function (e) { e.preventDefault(); }); build();
}

function boot() { initFx(); initPlayground(); initTabs(); initTools(); initCv(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
/* heavy visual layer after the page is interactive */
function late() { initBg(); }
if ('requestIdleCallback' in window) window.addEventListener('load', function () { requestIdleCallback(late, { timeout: 1500 }); });
else window.addEventListener('load', function () { setTimeout(late, 300); });
})();
